<?php


class Brizy_Editor_Constants {
	const USES_BRIZY = 'brizy-use-brizy';
}