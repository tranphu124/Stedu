<?php

class Brizy_Editor_Http_Exceptions_ResponseNotFound extends Brizy_Editor_Http_Exceptions_ResponseException {

}